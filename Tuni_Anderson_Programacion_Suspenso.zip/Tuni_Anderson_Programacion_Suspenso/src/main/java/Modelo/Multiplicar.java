/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author speyc
 */
public class Multiplicar extends Modelo{
    public float multit(){
        float multiplicacion1=0;
        multiplicacion1=(this.getNumero1()*this.getNumero2());
        return multiplicacion1;
    }
}
