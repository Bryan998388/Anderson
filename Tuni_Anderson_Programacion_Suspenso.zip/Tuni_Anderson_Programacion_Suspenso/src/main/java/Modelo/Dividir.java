/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @anderson tuni
 */
public class Dividir extends Modelo {
    public float Divt(){
        float dividir1=0;
        dividir1=(this.getNumero1()/this.getNumero2());
        return dividir1;
    }
    
}
