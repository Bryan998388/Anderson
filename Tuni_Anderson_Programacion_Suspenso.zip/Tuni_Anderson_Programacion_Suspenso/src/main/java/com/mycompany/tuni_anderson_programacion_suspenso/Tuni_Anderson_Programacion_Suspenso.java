/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tuni_anderson_programacion_suspenso;

import Vista.Vista;

/**
 *
 * @author speyc
 */
public class Tuni_Anderson_Programacion_Suspenso {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Vista bvista = new Vista();
        bvista.setVisible(true);
    }
}
